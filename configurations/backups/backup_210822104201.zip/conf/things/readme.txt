Your thing definitions go here.
All thing files have to have the ".things" file extension and must follow a special syntax.

Check out the openHAB documentation for more details:
https://www.openhab.org/docs/configuration/things.html
